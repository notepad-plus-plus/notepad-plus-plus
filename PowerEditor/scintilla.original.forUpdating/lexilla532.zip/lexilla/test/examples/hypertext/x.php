<head> <!-- About to script -->
<?php
decrypt "xyzzy";
echo __FILE__.__LINE__;
echo "<!-- -->\n";
/* ?> */
?>
<strong>for</strong><b>if</b>
<script>
	alert("<?php echo "PHP" . ' Code'; ?>");
	alert('<?= 'PHP' . "Code"; ?>');
	var xml =
	'<?xml version="1.0" encoding="iso-8859-1"?><SO_GL>' +
	'<GLOBAL_LIST mode="complete"><NAME>SO_SINGLE_MULTIPLE_COMMAND_BUILDER</NAME>' +
	'<LIST_ELEMENT><CODE>1</CODE><LIST_VALUE><![CDATA[RM QI WEB BOOKING]]></LIST_VALUE></LIST_ELEMENT>' +
	'<LIST_ELEMENT><CODE>1</CODE><LIST_VALUE><![CDATA[RM *PCC]]></LIST_VALUE></LIST_ELEMENT>' +
	'</GLOBAL_LIST></SO_GL>';
</script>
