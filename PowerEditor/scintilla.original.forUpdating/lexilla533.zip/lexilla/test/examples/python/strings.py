# Simple raw string
r''

# Raw f-string
rf''
fr''

# Raw byte string
rb''
br''

# Raw unicode strings: ur'' is valid in 2.7 (but not in 3) -- always lexed as
# valid; ru'' is never valid
ru''
ur''

