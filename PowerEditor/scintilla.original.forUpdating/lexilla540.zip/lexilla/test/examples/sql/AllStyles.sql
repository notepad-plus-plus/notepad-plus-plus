-- Enumerate all styles: 0 to 24

-- comment=1
/* comment */

-- whitespace=0
	-- w

/* commentline=2 */
-- commentline

-- commentdoc=3
/** commentdoc */

-- number=4
4

-- word=5
select

-- string=6
"string"

-- character=7
'character'

-- sqlplus=8
append

-- sqlplus_prompt=9
prompt SQL+Prompt

-- operator=10
+

-- identifier=11
identifier

-- sqlplus_comment=13
remark sqlplus comment

-- commentlinedoc=15
# commentlinedoc

-- word2=16
object

-- commentdockeyword=17
/** @return */

-- commentdockeyworderror=18
/** @error */

-- user1=19
dbms_output.disable

-- user2=20
analyze

-- user3=21
array

-- user4=22
false

-- quotedidentifier=23
`quotedidentifier`

-- qoperator=24
q'{ today's }'
