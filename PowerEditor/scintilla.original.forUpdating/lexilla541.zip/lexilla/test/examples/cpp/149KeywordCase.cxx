// SCE_C_WORD2 (16)
second

// SCE_C_IDENTIFIER (11)
Second

// SCE_C_IDENTIFIER (11)
upper

// SCE_C_WORD2 (16)
Upper
