# encoding: utf-8
puts <<A中
#{1+2}
A中

puts <<中
#{1+2}
中
