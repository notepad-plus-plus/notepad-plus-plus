<?
nl2br("\n); // unterminated string
?>
")
