# Float Literals
12.34
1234e-2
1.234E1
# Range Literals
(1..2)
(2.0..3)
# Method on number
1.5.ceil
1ri.abs
3.times {|i| puts i}
3. times {|i| puts i}
